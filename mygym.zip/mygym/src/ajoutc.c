#include <stdio.h>
#include <gtk/gtk.h>
#include "ajoutc.h"
#include <string.h>


void supprimer(char num[],int n)
{
cours s;
FILE*f;
FILE*f1;


f=fopen("cours.txt","a+");
f1=fopen("cours1.txt","a+");
if (f!=NULL)
{
while(fscanf(f,"%s %s %s %s\n",s.num,s.nom,s.jour,s.heure)!=EOF)
{
if(strcmp(num,s.num)!=0)
{
fprintf(f1,"%s %s %s %s\n",s.num,s.nom,s.jour,s.heure);
}


}
}
fclose(f);
fclose(f1);
remove("cours.txt");
rename("cours1.txt","cours.txt");

}


void modifier(cours s)
{
  cours c;
  FILE*f;
  FILE *f1;
  f=fopen("cours.txt","a+");
  f1=fopen("cours1.txt","a+");
  if(f!=NULL)
  {
    while(fscanf(f,"%s %s %s %s\n",c.num,c.nom,c.jour,c.heure)!=EOF)
    {
      if(strcmp(c.num,s.num)==0)
      {
        fprintf(f1,"%s %s %s %s\n",s.num,s.nom,s.jour,s.heure);
      }
      else fprintf(f1,"%s %s %s %s\n",c.num,c.nom,c.jour,c.heure);
    }
  }
  fclose(f);
  fclose(f1);
  remove("cours.txt");
  rename("cours1.txt","cours.txt");
}



enum
{
  NUM,
  NOM,
  JOUR,
  HEURE,

  COLUMNS
};

void afficher_cours(GtkWidget *liste)
{
  GtkCellRenderer *renderer;
  GtkTreeViewColumn *column;
  GtkTreeIter iter;
  GtkListStore *store;
  char num[50];
  char nom[50];
  char jour[50];
  char heure[50];
  
  store=NULL;

  FILE *f;
  store=gtk_tree_view_get_model(liste);
  if (store==NULL)
  {

    renderer= gtk_cell_renderer_text_new();
    column=   gtk_tree_view_column_new_with_attributes("num",renderer,"text",NUM,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
    renderer= gtk_cell_renderer_text_new();
    column= gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
    renderer= gtk_cell_renderer_text_new();
    column= gtk_tree_view_column_new_with_attributes("jour",renderer,"text",JOUR,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
    renderer= gtk_cell_renderer_text_new();
    column= gtk_tree_view_column_new_with_attributes("heure",renderer,"text",HEURE,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
  f=fopen("/home/zack/mygym/src/cours.txt", "r");
  if (f==NULL)
  {
    return;
  }
  else
  {
    f= fopen("/home/zack/mygym/src/cours.txt", "a+");
    while(fscanf(f,"%s %s %s %s\n",num,nom,jour,heure)!=EOF)
    {
      gtk_list_store_append(store, &iter);
      gtk_list_store_set(store, &iter,NUM,num,NOM,nom,JOUR,jour,HEURE,heure, -1);

    }
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref (store);
    }
  }



